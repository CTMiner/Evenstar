<?php
reserve_page("admin");
function getpage_admin() {
    require 'plugins/admin/dash.php';
}
?>