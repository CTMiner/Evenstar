</div>
<?php
if($jsLoc=="footer") {
    echo("    <script type=\"text/javascript\" src=\"themes/$theme/scripts.js\"></script>");
    /* doAction('LoadJS'); */
} ?>
</body>
</html>