<table><tr>
<td><a href="?page=home">Evenstar Home</a></td>
<td><a href="?page=about">About Evenstar</a></td>
<td><a href="?page=changelog">Changelog</a></td>
<td><a href="?page=approved-themes-plugins">Approved Themes &amp; Plugins</a></td>
<td><a href="http://ctminer.koding.com/">Main Site</a></td>
<td><a href="http://ctminer.koding.com/wp/">Blog</a></td>
</tr></table>