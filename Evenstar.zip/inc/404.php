<h1>404 - File not found</h1>
<p>The page you were trying to access can't be found. Try searching and check the link you used to come here.</p>
<?php global $request; if($request!="") { echo("<p>The page you tried to acces was: <u>" . $request . "</u></p>"); }