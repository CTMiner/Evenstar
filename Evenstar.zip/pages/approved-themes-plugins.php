<h2>Approved Themes</h2>
<ul>
    <li>Evenstar Navy (evenstar-navy) by CTMiner</li>
</ul>
<h2>Approved Plugins</h2>
<ul>
    <li>[WIP] Admin Dashboard (admin) by CTMiner</li>
</ul>