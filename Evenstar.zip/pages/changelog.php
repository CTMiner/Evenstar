<h2>Future Version 3.0</h2>
<ul>
    <li>[WIP] Admin Dashboard</li>
    <li>[WIP] Sidebars</li>
</ul>
<h2>Version 2.0</h2>
<ul>
    <li>Fixed & fully implemented hooks</li>
    <li>Moved 404 page from /pages/ to /inc/</li>
    <li>Moved themes from just 'drop it in themes' to folders in /themes/ and a variable in settings.php</li>
    <li>Fixed reserve_page()</li>
</ul>
<h2>Version 1.0</h2>
<ul>
    <li>Created base</li>
</ul>