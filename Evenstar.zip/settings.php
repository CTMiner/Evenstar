<?php
// Set variables here
$sitename = "Evenstar"; // Your site name here
$motto = "Dev location for testing and writing of Evenstar CMS"; // Your motto/slogan/tagline
$email = ""; // Your email here - leave blank to ignore
$sidebar = false; // true/false - Do you want sidebar enabled?
$jsLoc = "header"; // Set to "header" or "footer" for where you want to load JavaScript on page
$navbar = true; // Set to true/false - Enable/Disable navbar
$theme = "evenstar-navy"; // Set theme directory
?>